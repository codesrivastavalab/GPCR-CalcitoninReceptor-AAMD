
import numpy as np
import matplotlib.pyplot as plt
import MDAnalysis as mda
from MDAnalysis.analysis import distances
import seaborn as sns
import pandas as pd


start = 0
stop = 8001
boundary = 10
cut_off = 5.5

def min_dist_calc(res_i,res_j,cut):
    if res_j.n_atoms != 0:
        dist_matrix_resij = distances.distance_array(res_i , res_j)
        min_dist_resij = np.min(dist_matrix_resij)
    else:
        min_dist_resij = cut
    
    return min_dist_resij

u_wt = mda.Universe("/media/new_volume/project_ctr/sims/mut_sys/ctr_tr/no_PTM/ctr_tr_6_lip/charmm-gui/charmm-gui-7026214540/gromacs/prd.1.conv.tpr","/media/new_volume/project_ctr/sims/mut_sys/ctr_tr/no_PTM/ctr_tr_6_lip/charmm-gui/charmm-gui-7026214540/gromacs/prd.1_5_trjconv.xtc")

u_mt = mda.Universe("/media/new_volume/project_ctr/sims/sims_with_ss/mut_sys/r404c_rebuilt/run1/prd.0.conv.tpr", "/media/new_volume/project_ctr/sims/sims_with_ss/mut_sys/r404c_rebuilt/run1/prd.0-3.conv.xtc")

ctr_res_wt = u_wt.select_atoms("resid 404 and not element H")
SAPI_res_wt = u_wt.select_atoms("( resname SAPI24 and name OP* ) and around "+"{0}".format(boundary)+" resid 404", updating = True)

ctr_res_mt = u_mt.select_atoms("resid 404 and not element H")
SAPI_res_mt = u_mt.select_atoms("( resname SAPI24 and name OP* ) and around "+"{0}".format(boundary)+" resid 404", updating = True)


l_dist_wt = np.array([])
for ts in u_wt.trajectory[start:stop]:
    ctr_res_wt = u_wt.select_atoms("resid 404 and not element H")
    SAPI_res_wt = u_wt.select_atoms("( resname SAPI24 and name OP* ) and around "+"{0}".format(boundary)+" resid 404", updating = True)

    dist = min_dist_calc(ctr_res_wt,SAPI_res_wt, boundary)
    l_dist_wt = np.append(l_dist_wt, dist)

l_filt_wt = l_dist_wt[l_dist_wt < cut_off ]
ocup_wt = (np.size(l_filt_wt)/np.size(l_dist_wt))*100

l_dist_mt = np.array([])
for ts in u_mt.trajectory[start:stop]:
    ctr_res_mt = u_mt.select_atoms("resid 404 and not element H")
    SAPI_res_mt = u_mt.select_atoms("( resname SAPI24 and name OP* ) and around "+"{0}".format(boundary)+" resid 404", updating = True)
    dist = min_dist_calc(ctr_res_mt,SAPI_res_mt, boundary)
    l_dist_mt = np.append(l_dist_mt, dist)

l_filt_mt = l_dist_mt[l_dist_mt < cut_off ]
ocup_mt = (np.size(l_filt_mt)/np.size(l_dist_mt))*100

x_mt = np.arange(0,l_dist_mt.size) *0.1
x_wt = np.arange(0,l_dist_wt.size) *0.1


def line_hist(x, y, label, color, ax, ax_histy):
     # no labels

    ax_histy.tick_params(axis="y", labelleft=False)

    # the line plot:
    y_avg = pd.DataFrame(y).rolling(50).mean() 
    ax.plot(x, y, alpha = 0.25, color = color)
    ax.plot(x,y_avg[0].values, label=label, color = color)
    ax.set_ylabel("Distance (Å)", fontsize = 18)
    ax.set_xlabel("Time (ns)", fontsize = 18)
    ax.legend(loc='upper right')
    ax_histy = sns.kdeplot(y, fill=True, ax=ax_histy, vertical=True, color = color)
    ax_histy.set_xlabel("Density", fontsize=18)


# Create a Figure, which doesn't have to be square.
fig = plt.figure(layout="constrained")
text = '\n'.join((
r'$\mathrm{occupancy\_wt}=%.2f$' % (ocup_wt, ),
r'$\mathrm{occupancy\_mutant}=%.2f$' % (ocup_mt, )))
props = dict(boxstyle='round', facecolor='lightcyan', alpha=0.2)

ax = fig.add_gridspec(right=0.75).subplots()
ax_histy = ax.inset_axes([1.05, 0, 0.25, 1], sharey=ax)
line_hist(x_wt, l_dist_wt, "CTR_wt", 'orange', ax, ax_histy)
line_hist(x_mt, l_dist_mt, "CTR_R404C", 'cyan', ax, ax_histy)
ax.text(0.05, 0.95, text, transform=ax.transAxes ,verticalalignment='top', bbox=props)
plt.title("Distance between CTR_res404 and PIP2 @ cut_off = "+"{0}".format(cut_off)+"Å", pad = 25, fontsize = 22, loc = 'center', wrap = True)
plt.savefig("ctr_res404_pip2_dist_ctr_wt_vs_ctr_r404c.png", dpi= 1200, bbox_inches='tight')
plt.show()
