import numpy as np
import matplotlib.pyplot as plt
import MDAnalysis as mda
from MDAnalysis.analysis import distances
import seaborn as sns
import pandas as pd


u_wt = mda.Universe("/media/new_volume/project_ctr/sims/mut_sys/ctr_tr/no_PTM/ctr_tr_6_lip/charmm-gui/charmm-gui-7026214540/gromacs/prd.0.trjconv.pdb", "/media/new_volume/project_ctr/sims/mut_sys/ctr_tr/no_PTM/ctr_tr_6_lip/charmm-gui/charmm-gui-7026214540/gromacs/prd.1_5_trjconv.xtc")

u_mt = mda.Universe("/media/new_volume/project_ctr/sims/mut_sys/ctr_tr/no_PTM/A307V/charmm-gui/charmm-gui-7113214527/gromacs/eqb6.6.conv.pdb", "/media/new_volume/project_ctr/sims/mut_sys/ctr_tr/no_PTM/A307V/charmm-gui/charmm-gui-7113214527/gromacs/prd.1_5_conv.xtc")

def min_dist_calc(res_i,res_j):
    dist_matrix_resij = distances.distance_array(res_i , res_j)
    min_dist_resij = np.min(dist_matrix_resij)
    
    return min_dist_resij

wt_ctr_306 = u_wt.select_atoms("chainID A and resid 306 and not name O C CA N HA HN")
wt_ctr_307 = u_wt.select_atoms("chainID A and resid 307 and not name O C CA N HA HN")

mt_ctr_306 = u_mt.select_atoms("chainID A and resid 306 and not name O C CA N HA HN")
mt_ctr_307 = u_mt.select_atoms("chainID A and resid 307 and not name O C CA N HA HN")

l_dist_wt = np.array([])
for ts in u_wt.trajectory:
    dist = min_dist_calc(wt_ctr_306, wt_ctr_307)
    l_dist_wt = np.append(l_dist_wt,dist)

l_dist_mt = np.array([])
for ts in u_mt.trajectory:
    dist = min_dist_calc(mt_ctr_306, mt_ctr_307)
    l_dist_mt = np.append(l_dist_mt,dist)

x_wt = np.arange(0,l_dist_wt.size)*0.1

def line_hist(x, y, label, color, ax, ax_histy):
     # no labels

    ax_histy.tick_params(axis="y", labelleft=False)

    # the line plot:
    y_avg = pd.DataFrame(y).rolling(80).mean() 
    ax.plot(x, y, alpha = 0.4, color = color)
    ax.plot(x,y_avg[0].values, label=label, color = color)
    ax.set_ylabel("Distance (Å)", fontsize = 18)
    ax.set_xlabel("Time (ns)", fontsize = 18)
    ax.legend(loc='upper right')
    ax_histy = sns.kdeplot(y, fill=True, ax=ax_histy, vertical=True, color = color)
    ax_histy.set_xlabel("Density", fontsize=18)


# Create a Figure, which doesn't have to be square.
fig = plt.figure(layout="constrained")
ax = fig.add_gridspec(right=0.75).subplots()
ax_histy = ax.inset_axes([1.05, 0, 0.25, 1], sharey=ax)
line_hist(x_wt, l_dist_wt, "CTR_wt", 'orange', ax, ax_histy)
line_hist(x_wt, l_dist_mt, "CTR_A307V", 'cyan', ax, ax_histy)
plt.title("Distance Plot between CTR:307 & CTR:306", pad = 25, fontsize = 24, loc = 'center', wrap = True)
plt.savefig("ctr_306_307_dist_A30V.png", dpi= 1200, bbox_inches='tight')
plt.show()
