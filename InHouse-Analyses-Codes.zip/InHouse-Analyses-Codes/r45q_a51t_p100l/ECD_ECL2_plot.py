import numpy as np
import matplotlib.pyplot as plt
import MDAnalysis as mda
from MDAnalysis.analysis import distances
import seaborn as sns
import pandas as pd

u_wt = mda.Universe("/media/new_volume/project_ctr/sims/sims_with_ss/ct_ctr_25_428_active/charmm-gui/charmm-gui-1533473484/gromacs/eqb6.6.conv.pdb", "/media/new_volume/project_ctr/sims/sims_with_ss/ct_ctr_25_428_active/charmm-gui/charmm-gui-1533473484/gromacs/prd.0-3.conv.xtc")

u_mt = mda.Universe("/media/new_volume/project_ctr/sims/sims_with_ss/mut_sys/ct_ctr_a51t/charmm-gui/charmm-gui-2009818543/gromacs/eqb6.6.conv.pdb", "/media/new_volume/project_ctr/sims/sims_with_ss/mut_sys/ct_ctr_a51t/charmm-gui/charmm-gui-2009818543/gromacs/prd.0-2.conv.xtc")

#u_mt_0 = mda.Universe("/media/new_volume/project_ctr/sims/sims_with_ss/mut_sys/ctr_a51t/charmm-gui/charmm-gui-1760457953/gromacs/eqb6.6.conv.pdb","/media/new_volume/project_ctr/sims/sims_with_ss/mut_sys/ctr_a51t/charmm-gui/charmm-gui-1760457953/gromacs/prd.0-2.conv.xtc")

def min_dist_calc(res_i,res_j):
    dist_matrix_resij = distances.distance_array(res_i , res_j)
    min_dist_resij = np.min(dist_matrix_resij)
    
    return min_dist_resij

def atom_pick(u, chainID, resid):
    atom_grp = u.select_atoms("chainID "+"{0}".format(chainID)+" and resid "+"{0}".format(resid))
    return atom_grp

ecl2_res = "285 to 296"
ecd_res = "37 to 47"

start = 0
stop = 6001

dist_wt = np.array([])
dist_mt = np.array([])
dist_mt_0 = np.array([])

for t,ts in enumerate(u_wt.trajectory[start:stop]):
    resi = atom_pick(u_wt,"B",ecl2_res)
    resj = atom_pick(u_wt,"B",ecd_res)
    dist_ij = min_dist_calc(resi,resj)
    dist_wt = np.append(dist_wt,dist_ij)
    
for t,ts in enumerate(u_mt.trajectory[start:stop]):
    resi = atom_pick(u_mt,"B",ecl2_res)
    resj = atom_pick(u_mt,"B",ecd_res)
    dist_ij = min_dist_calc(resi,resj)
    dist_mt = np.append(dist_mt,dist_ij)

""" for t,ts in enumerate(u_mt_0.trajectory[start:stop]):
    resi = atom_pick(u_mt_0,"A",ecl2_res)
    resj = atom_pick(u_mt_0,"A",ecd_res)
    dist_ij = min_dist_calc(resi,resj)
    dist_mt_0 = np.append(dist_mt_0,dist_ij) """
    
x_wt = np.arange(start,stop) * 0.1
x_mt = np.arange(start,stop) * 0.1
# x_mt_0 = np.arange(start,stop) * 0.1

def line_hist(x, y, label, color, ax, ax_histy):
     # no labels
    ax_histy.tick_params(axis="y", labelleft=False)

    # the line plot:
    y_avg = pd.DataFrame(y).rolling(50).mean() 
    ax.plot(x, y, alpha = 0.25, color = color)
    ax.plot(x,y_avg[0].values, label=label, color = color)
    ax.set_ylabel("Distance (Å)", fontsize = 18)
    ax.set_xlabel("Time (ns)", fontsize = 18)
    ax.legend(loc='upper right')
    ax_histy = sns.kdeplot(y, fill=True, ax=ax_histy, vertical=True, color = color)
    ax_histy.set_xlabel("Density", fontsize=18)


fig = plt.figure(layout="constrained")
ax = fig.add_gridspec(right=0.75).subplots() 
ax_histy = ax.inset_axes([1.05, 0, 0.25, 1], sharey=ax)
line_hist(x_wt, dist_wt, "CT_CTR_wt", 'orange', ax, ax_histy)
line_hist(x_mt, dist_mt, "CT_CTR_A51T", 'cyan', ax, ax_histy)
# line_hist(x_mt_0, dist_mt_0, "CTR_A51T", 'blue', ax, ax_histy)
plt.title("Distance between ECD helix and ECL2", pad = 25, fontsize = 24, loc = 'center', wrap = True)
plt.savefig("ecd_ecl2_dist_A51T_4.png", dpi= 1200, bbox_inches='tight')
plt.show()
