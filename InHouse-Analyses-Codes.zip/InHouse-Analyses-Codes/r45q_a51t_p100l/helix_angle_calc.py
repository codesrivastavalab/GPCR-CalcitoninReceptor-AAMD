import numpy as np
import matplotlib.pyplot as plt
import MDAnalysis as mda
import seaborn as sns
import pandas as pd


u_mutant = mda.Universe("/media/new_volume/project_ctr/sims/sims_with_ss/mut_sys/ct_ctr_a51t/charmm-gui/charmm-gui-2009818543/gromacs/eqb6.6.conv.pdb", "/media/new_volume/project_ctr/sims/sims_with_ss/mut_sys/ct_ctr_a51t/charmm-gui/charmm-gui-2009818543/gromacs/prd.0-2.conv.xtc")

u_wt = mda.Universe("/media/new_volume/project_ctr/sims/sims_with_ss/ct_ctr_25_428_active/charmm-gui/charmm-gui-1533473484/gromacs/eqb6.6.conv.pdb", "/media/new_volume/project_ctr/sims/sims_with_ss/ct_ctr_25_428_active/charmm-gui/charmm-gui-1533473484/gromacs/prd.0-3.conv.xtc")

z_unit = np.array([0,0,1])
res_pair1 = np.array([46, 57])

total_pairs = np.array([res_pair1])

def extract_pos(u, resid):
    pos = u.select_atoms("resid " +"{0}".format(resid) +" and name CA").positions[0]
    return pos

def vector_gen(pos1:np.ndarray, pos2:np.ndarray):
    v1 = pos2 - pos1
    return v1

def angle_calc(pl1:np.ndarray, pl2:np.ndarray):

    def unit_vector(pl:np.ndarray):
        return pl / np.linalg.norm(pl)
    
    pl1_unit = unit_vector(pl1)
    pl2_unit = unit_vector(pl2)
    ang_d = np.degrees(np.arccos(np.clip(np.dot(pl1_unit, pl2_unit), -1.0, 1.0)))
    #ang_d = np.degrees(np.arccos(np.dot(pl1_unit, pl2_unit)))
    
    return round(ang_d, 2)

def angle_sign(v1:np.ndarray, p_v1:np.ndarray, q_p:np.ndarray):
    """
    parameters:
    v1: vector perpendicular to the plane
    p_v1: any point on the plane
    q_p: query vector

    returns: the values +1, 0, -1 for out of the plane, on the plane or inside the plane. 

    """
    v2 = q_p - p_v1
    dot = np.dot(v1,v2)
    sign = 0
    if dot != 0:
        sign = dot / abs(dot)

    return sign
    


res_angle_mut = np.empty((0,np.size(total_pairs[:,0])))
res_angle_wt = np.empty((0,np.size(total_pairs[:,0])))

for ts_m, ts_w in zip(u_mutant.trajectory[0:6001], u_wt.trajectory[0:6001]): 

    res_ang_mut_temp = np.array([])
    res_ang_wt_temp = np.array([])

    for i, pair in enumerate(total_pairs):
        
        pos1_m = extract_pos(u_mutant, pair[0])
        pos2_m = extract_pos(u_mutant, pair[1])
        vec1_m = vector_gen(pos1_m, pos2_m)
        ang1_m = angle_calc(z_unit,vec1_m)
        res_ang_mut_temp = np.append(res_ang_mut_temp, ang1_m)

        pos1_wt = extract_pos(u_wt, pair[0])
        pos2_wt = extract_pos(u_wt, pair[1])
        vec1_wt = vector_gen(pos1_wt, pos2_wt)
        ang1_wt = angle_calc(z_unit, vec1_wt)
        res_ang_wt_temp = np.append(res_ang_wt_temp, ang1_wt)
    
    res_angle_mut = np.vstack((res_angle_mut, res_ang_mut_temp))
    res_angle_wt = np.vstack((res_angle_wt, res_ang_wt_temp))


x_mut = np.arange(0, res_angle_mut[:,0].size)*0.1
x_wt = np.arange(0, res_angle_wt[:,0].size)*0.1

# Create figure
def line_hist(x, y, label, color, ax, ax_histy):
    
    ax_histy.tick_params(axis="y", labelleft=False)

    # the line plot:
    y_avg = pd.DataFrame(y).rolling(50).mean() 
    ax.plot(x, y, alpha = 0.25, color = color)
    ax.plot(x,y_avg[0].values, label=label, color = color)
    ax.set_ylabel("Angle (Degree)", fontsize = 18)
    ax.set_xlabel("Time (ns)", fontsize = 18)
    ax.legend(loc='upper right')
    ax_histy = sns.kdeplot(y, fill=True, ax=ax_histy, vertical=True, color = color)
    ax_histy.set_xlabel("Density", fontsize=18)


for i in range(np.size(total_pairs[:,0])):
    fig = plt.figure(layout="constrained")
    ax = fig.add_gridspec(right=0.75).subplots()
    ax_histy = ax.inset_axes([1.05, 0, 0.25, 1], sharey=ax)
    line_hist(x_wt, res_angle_wt[:,i], "CT_CTR_wt", 'orange', ax, ax_histy)
    line_hist(x_mut, res_angle_mut[:,i], "CT_CTR_A51T", 'cyan', ax, ax_histy)
    plt.title("ECD Helix angle distribution w.r.t Z-axis", pad = 25, fontsize = 24, loc = 'center', wrap = True)
    plt.savefig("ECD_helix_angle_distribution_ctr_wt_vs_ctr_A51T_2.png", dpi= 1200, bbox_inches='tight')
    plt.show()
