import numpy as np
import matplotlib.pyplot as plt
import MDAnalysis as mda
from MDAnalysis.analysis import distances
import seaborn as sns
import pandas as pd


u_mutant = mda.Universe("/media/new_volume/project_ctr/sims/mut_sys/ctr_tr/no_PTM/V250M/charmm-gui/docking/ctr_v250_5224_system/ctr_g_gdp_ss/charmm-gui/charmm-gui-0912108318/gromacs/prd.0.conv_sm.tpr", "/media/new_volume/project_ctr/sims/mut_sys/ctr_tr/no_PTM/V250M/charmm-gui/docking/ctr_v250_5224_system/ctr_g_gdp_ss/charmm-gui/charmm-gui-0912108318/gromacs/prd.0_3.conv_sm.xtc")

u_wt = mda.Universe("/run/media/prithvi_l109/prithvi_4.1/bkup/ctr_project_sims/multi_comp_sys/ctr_g_comp_gd-tp/ctr_tr_1_428_g_comp_gdp/ctr_tr_1_428_g_gdp_charmm-gui/charmm-gui-5362819393/gromacs/prdf1.tpr", "/run/media/prithvi_l109/prithvi_4.1/bkup/ctr_project_sims/multi_comp_sys/ctr_g_comp_gd-tp/ctr_tr_1_428_g_comp_gdp/ctr_tr_1_428_g_gdp_charmm-gui/charmm-gui-5362819393/gromacs/prd.0-4.conv.xtc")

""" 
CTR: resid 1-428 = resid 772-1190
Ga: resid 17-394 = resid 1-378

"""

def min_dist_calc(res_i,res_j):
    dist_matrix_resij = distances.distance_array(res_i , res_j)
    min_dist_resij = np.min(dist_matrix_resij)
    
    return min_dist_resij

ctr_res_mutant = u_mutant.select_atoms("resid 1167 and not element H") # CTR_resid : 396
ga_res_mutant = u_mutant.select_atoms("resid 376 and not element H")  # Ga_resid : 392

ctr_res_wt = u_wt.select_atoms("resid 1167 and not element H") # CTR_resid : 396
ga_res_wt = u_wt.select_atoms("resid 376 and not element H")  # Ga_resid : 392


l_dist_mutant = np.array([])
for ts in u_mutant.trajectory:
    dist = min_dist_calc(ctr_res_mutant, ga_res_mutant)
    l_dist_mutant = np.append(l_dist_mutant,dist)

l_dist_wt = np.array([])
for ts in u_wt.trajectory[0:8001]:
    dist = min_dist_calc(ctr_res_wt, ga_res_wt)
    l_dist_wt = np.append(l_dist_wt,dist)


x_mutant = np.arange(0,l_dist_mutant.size) *0.1
x_wt = np.arange(0,l_dist_wt.size) *0.1

df_wt = pd.DataFrame(np.column_stack((x_wt, l_dist_wt)), columns=['time_frame', 'distance_ctr_ga'])
df_mutant = pd.DataFrame(np.column_stack((x_mutant, l_dist_mutant)), columns=['time_frame', 'distance_ctr_ga'])

with pd.ExcelWriter('ctr_ga_dist_figure_6_D.xlsx') as writer:
    df_wt.to_excel(writer, sheet_name='CALCR_WT')
    df_mutant.to_excel(writer, sheet_name='CALCR_V250M')

def line_hist(x, y, label, color, ax, ax_histy):
     # no labels

    ax_histy.tick_params(axis="y", labelleft=False)

    # the line plot:
    y_avg = pd.DataFrame(y).rolling(80).mean() 
    ax.plot(x, y, alpha = 0.4, color = color)
    ax.plot(x,y_avg[0].values, label=label, color = color)
    ax.set_ylabel("Distance (Å)", fontsize = 18)
    ax.set_xlabel("Time (ns)", fontsize = 18)
    ax.legend()
    ax_histy = sns.kdeplot(y, fill=True, ax=ax_histy, vertical=True, color = color)
    ax_histy.set_xlabel("Density", fontsize=18)  




# Create a Figure, which doesn't have to be square.
fig = plt.figure(layout="constrained")

ax = fig.add_gridspec(right=0.75).subplots()

ax_histy = ax.inset_axes([1.05, 0, 0.25, 1], sharey=ax)
line_hist(x_wt, l_dist_wt, "CTR_wt", 'orange', ax, ax_histy)
line_hist(x_mutant, l_dist_mutant, "CTR_V250M", 'cyan', ax, ax_histy)
plt.title("Distance between CTR and G-alpha", pad = 25, fontsize = 24, loc = 'center', wrap = True)
plt.savefig("ctr_ga_dist_ctr_wt_vs_ctr_v250m.png", dpi= 1200, bbox_inches='tight')
plt.show()

