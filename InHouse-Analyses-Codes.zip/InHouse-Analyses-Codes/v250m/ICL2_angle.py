import numpy as np
import matplotlib.pyplot as plt
import MDAnalysis as mda
from MDAnalysis.analysis import distances
import seaborn as sns
import pandas as pd


u_mutant = mda.Universe("/media/new_volume/project_ctr/sims/mut_sys/ctr_tr/no_PTM/V250M/charmm-gui/charmm-gui-7113366156/gromacs/prd.0.r.tpr", "/media/new_volume/project_ctr/sims/mut_sys/ctr_tr/no_PTM/V250M/charmm-gui/charmm-gui-7113366156/gromacs/prd.0_4_conv.r.xtc")

u_wt = mda.Universe("/media/new_volume/project_ctr/sims/mut_sys/ctr_tr/no_PTM/ctr_tr_6_lip/charmm-gui/charmm-gui-7026214540/gromacs/prd.0.conv.r.tpr","/media/new_volume/project_ctr/sims/mut_sys/ctr_tr/no_PTM/ctr_tr_6_lip/charmm-gui/charmm-gui-7026214540/gromacs/prd.1_5_trjconv.r.xtc")


resid = np.array([252, 253, 254, 255])
resid_plane = np.array([241, 248, 260])


def plane_gen(pos1:np.ndarray, pos2:np.ndarray, pos3:np.ndarray):
    v1 = pos1 - pos3
    v2 = pos2 - pos3
    plane = np.cross(v1, v2)
    return plane

def angle_calc(pl1:np.ndarray, pl2:np.ndarray):

    def unit_vector(pl:np.ndarray):
        return pl / np.linalg.norm(pl)
    
    pl1_unit = unit_vector(pl1)
    pl2_unit = unit_vector(pl2)
    #ang_d = np.degrees(np.arccos(np.clip(np.dot(pl1_unit, pl2_unit), -1.0, 1.0)))
    ang_d = np.degrees(np.arccos(np.dot(pl1_unit, pl2_unit)))
    #ang_d = np.degrees(np.arcsin(np.cross(pl1_unit,pl2_unit)))
    
    #return round(dot, 2)
    return round(ang_d, 2)

def angle_sign(v1:np.ndarray, p_v1:np.ndarray, q_p:np.ndarray):
    """
    parameters:
    v1: vector perpendicular to the plane
    p_v1: any point on the plane
    q_p: query vector

    returns: the values +1, 0, -1 for out of the plane, on the plane or inside the plane. 

    """
    v2 = q_p - p_v1
    dot = np.dot(v1,v2)
    sign = 0
    if dot != 0:
        sign = dot / abs(dot)

    return sign
    

def extract_pos(u, resid):
    pos = u.select_atoms("resid " +"{0}".format(resid) +" and name CA").positions[0]
    return pos


res_angle_mut = np.empty((0,np.size(resid)))
res_angle_wt = np.empty((0,np.size(resid)))

for ts_m, ts_w in zip(u_mutant.trajectory, u_wt.trajectory): 

    pos_0_mutant = np.empty((0,3))
    pos_0_wt = np.empty((0,3))
    for res in resid_plane:
        pos_m = extract_pos(u_mutant, res)
        pos_wt = extract_pos(u_wt, res)
        pos_0_mutant= np.vstack((pos_0_mutant,pos_m))
        pos_0_wt= np.vstack((pos_0_wt,pos_wt))

    plane_0_mutant = plane_gen(pos_0_mutant[0],pos_0_mutant[1],pos_0_mutant[2])
    plane_0_wt = plane_gen(pos_0_wt[0],pos_0_wt[1],pos_0_wt[2])


    res_angle_mut_temp = np.array([])
    res_angle_wt_temp = np.array([])
    for res in resid:
        pos_m = extract_pos(u_mutant, res)
        plane_m = plane_gen(pos_0_mutant[1], pos_m, pos_0_mutant[2])
        ang_sign_mut = angle_sign(plane_0_mutant,pos_0_mutant[1], pos_m)
        angle_m = ang_sign_mut * (angle_calc(plane_0_mutant,plane_m))
        res_angle_mut_temp = np.append(res_angle_mut_temp, angle_m)

        pos_wt = extract_pos(u_wt, res)
        plane_wt =  plane_gen(pos_0_wt[1], pos_wt, pos_0_wt[2])
        ang_sign_wt = angle_sign(plane_0_wt,pos_0_wt[1], pos_wt)
        angle_wt = ang_sign_wt * (angle_calc(plane_0_wt,plane_wt))
        res_angle_wt_temp = np.append(res_angle_wt_temp, angle_wt)
    
    res_angle_mut = np.vstack((res_angle_mut, res_angle_mut_temp))
    res_angle_wt = np.vstack((res_angle_wt, res_angle_wt_temp))
    


x_mut = np.arange(0, res_angle_mut[:,0].size) *0.1
x_wt = np.arange(0, res_angle_wt[:,0].size) *0.1

df_wt = pd.DataFrame(np.column_stack((x_wt,res_angle_wt)), columns=['time_frame', 'resid_252', 'resid_253', 'resid_254', 'resid_255'])

df_mut = pd.DataFrame(np.column_stack((x_mut,res_angle_mut)), columns=['time_frame', 'resid_252', 'resid_253', 'resid_254', 'resid_255'])

with pd.ExcelWriter('ICL_angle_distribution_figure_6_B.xlsx') as writer:
    df_wt.to_excel(writer, sheet_name='ICL_WT')
    df_mut.to_excel(writer, sheet_name='ICL_V250M')

# Create figure
def line_hist(x, y, label, color, ax, ax_histy):
    
    ax_histy.tick_params(axis="y", labelleft=False)

    # the line plot:
    y_avg = pd.DataFrame(y).rolling(50).mean() 
    ax.plot(x, y, alpha = 0.25, color = color)
    ax.plot(x,y_avg[0].values, label=label, color = color)
    ax.set_ylabel("Angle (degree)", fontsize = 18)
    ax.set_xlabel("Time (ns)", fontsize = 18)
    ax.legend()
    ax_histy = sns.kdeplot(y, fill=True, ax=ax_histy, vertical=True, color = color)
    ax_histy.set_xlabel("Density", fontsize=18)
       
""" def line_hist(x, y, label, color, ax, ax_histy):
    
    ax_histy.tick_params(axis="y", labelleft=False)

    # the line plot:
    y_avg = pd.DataFrame(y).rolling(50).mean() 
    ax.plot(x, y, alpha = 0.25, color = color)
    ax.plot(x,y_avg[0].values, label=label, color = color)
    ax.set_ylabel("Angle in degree", fontsize = 20)
    ax.set_xlabel("Time(ns)", fontsize = 20)
    ax.legend()
    binwidth = 0.5
    ymax = np.max(np.abs(y))
    lim = (int(ymax/binwidth) + 1) * binwidth
    bins = np.arange(-lim, lim + binwidth, binwidth)
    ax_histy.hist(y, bins=bins, color =color, fill=True, alpha = 0.4, orientation='horizontal')     
    ax_histy.set_xlabel("Density", fontsize=20) """



for i,r in enumerate(resid):
    fig = plt.figure(layout="constrained")
    ax = fig.add_gridspec(right=0.75).subplots()
    ax_histy = ax.inset_axes([1.05, 0, 0.25, 1], sharey=ax)
    line_hist(x_wt, res_angle_wt[:,i], "CTR_wt_"+"{0}".format(r), 'orange', ax, ax_histy)
    line_hist(x_mut, res_angle_mut[:,i], "CTR_V250M_"+"{0}".format(r), 'cyan', ax, ax_histy)
    plt.title("ICL2 angle distribution", pad = 25, fontsize = 24)
    plt.savefig("ICL2_angle_distribution_ctr_wt_vs_ctr_v250m_res"+"{0}".format(r)+".png", dpi= 1200)
    plt.show()


