import numpy as np
import matplotlib.pyplot as plt
import MDAnalysis as mda
from MDAnalysis.analysis import distances
import seaborn as sns
import pandas as pd


u_mutant = mda.Universe("/media/new_volume/project_ctr/sims/mut_sys/ctr_tr/no_PTM/V250M/charmm-gui/charmm-gui-7113366156/gromacs/prd.0.r.tpr", "/media/new_volume/project_ctr/sims/mut_sys/ctr_tr/no_PTM/V250M/charmm-gui/charmm-gui-7113366156/gromacs/prd.0_4_conv.r.xtc")

u_wt = mda.Universe("/media/new_volume/project_ctr/sims/mut_sys/ctr_tr/no_PTM/ctr_tr_6_lip/charmm-gui/charmm-gui-7026214540/gromacs/prd.0.conv.r.tpr","/media/new_volume/project_ctr/sims/mut_sys/ctr_tr/no_PTM/ctr_tr_6_lip/charmm-gui/charmm-gui-7026214540/gromacs/prd.1_5_trjconv.r.xtc")



def min_dist_calc(res_i,res_j):
    dist_matrix_resij = distances.distance_array(res_i , res_j)
    min_dist_resij = np.min(dist_matrix_resij)
    
    return min_dist_resij

ctr_tm3_mutant = u_mutant.select_atoms("resid 250 and name CA") # CTR_tm3 : 250 
ctr_tm5_mutant = u_mutant.select_atoms("resid 326 and name CA")  # CTR_tm5 : 326

ctr_tm3_wt = u_wt.select_atoms("resid 250 and name CA") # CTR_tm3 : 250
ctr_tm5_wt = u_wt.select_atoms("resid 326 and name CA")  # CTR_tm5 : 326


l_dist_mutant = np.array([])
for ts in u_mutant.trajectory:
    dist = min_dist_calc(ctr_tm3_mutant, ctr_tm5_mutant)
    l_dist_mutant = np.append(l_dist_mutant,dist)

l_dist_wt = np.array([])
for ts in u_wt.trajectory:
    dist = min_dist_calc(ctr_tm3_wt, ctr_tm5_wt)
    l_dist_wt = np.append(l_dist_wt,dist)


x_mutant = np.arange(0,l_dist_mutant.size) *0.1
x_wt = np.arange(0,l_dist_wt.size) *0.1


df_wt = pd.DataFrame(np.column_stack((x_wt, l_dist_wt)), columns=['time_frame', 'distance_250_326'])
df_mutant = pd.DataFrame(np.column_stack((x_mutant, l_dist_mutant)), columns=['time_frame', 'distance_250_326'])

with pd.ExcelWriter('TM3_TM5_dist_figure_6_D.xlsx') as writer:
    df_wt.to_excel(writer, sheet_name='CALCR_WT')
    df_mutant.to_excel(writer, sheet_name='CALCR_V250M')

def line_hist(x, y, label, color, ax, ax_histy):
     # no labels

    ax_histy.tick_params(axis="y", labelleft=False)

    # the line plot:
    y_avg = pd.DataFrame(y).rolling(50).mean() 
    ax.plot(x, y, alpha = 0.25, color = color)
    ax.plot(x,y_avg[0].values, label=label, color = color)
    ax.set_ylabel("Distance (Å)", fontsize = 18)
    ax.set_xlabel("Time (ns)", fontsize = 18)
    ax.legend()
    ax_histy = sns.kdeplot(y, fill=True, ax=ax_histy, vertical=True, color = color)
    ax_histy.set_xlabel("Density", fontsize=18)



# Create a Figure, which doesn't have to be square.
fig = plt.figure(layout="constrained")

ax = fig.add_gridspec(right=0.75).subplots()

ax_histy = ax.inset_axes([1.05, 0, 0.25, 1], sharey=ax)
line_hist(x_wt, l_dist_wt, "CTR_wt", 'orange', ax, ax_histy)
line_hist(x_mutant, l_dist_mutant, "CTR_V250M", 'cyan', ax, ax_histy)
plt.title("Distance between TM3 and TM5 of CTR", pad = 25, fontsize = 24, loc = 'center', wrap = True)
plt.savefig("ctr_tm3_tm5_dist_ctr_wt_vs_ctr_v250m.png", dpi= 1200,bbox_inches='tight')
plt.show()

